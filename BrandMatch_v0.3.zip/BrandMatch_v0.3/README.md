# BrandMatch v0.3

## What's new
- Export a client-specific, standalone branded HTML game with its branding embedded.
- Export/import JSON configuration remains available.
- Exported branded games no longer load the generic app's saved localStorage branding over the embedded client config.

## Test on desktop
1. Extract the ZIP and open `index.html` in Chrome or Edge.
2. Open Business branding settings. Change name, color, logo, products, and reward text.
3. Click Apply branding, then Download branded game.
4. Open the downloaded `*-branded-game.html` in a separate tab or browser profile. Confirm the client's branding appears without needing to configure it again.
5. Refresh and test gameplay. Try export/import JSON too.

## Android notes
This remains a browser-based prototype, not an APK. Opening HTML locally on Android is useful for a smoke test but is not equivalent to a reliable installable app. For a real installable PWA, host it over HTTPS and add a service worker plus app icons; for a native Android package, wrap and test the hosted web app with a free toolchain such as Capacitor/Android Studio.

## Commercial readiness checklist
- Test gameplay, small-screen layout, branding, exported files, and saved settings on multiple browsers/devices.
- Do not promise coupon validation, analytics, or cross-device syncing: they are not implemented.
- Confirm the business owns or has permission to use its logo, product images, and offer copy.
- Agree on deliverables, updates, and promotion terms in writing before taking payment.
